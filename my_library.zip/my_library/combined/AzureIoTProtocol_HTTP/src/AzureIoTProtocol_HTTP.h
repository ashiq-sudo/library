// Copyright (c) Microsoft. All rights reserved.
// Licensed under the MIT license. See LICENSE file in the project root for full license information.

#ifndef AZUREIOTPROTOCOLHTTP_H
#define AZUREIOTPROTOCOLHTTP_H

#define AzureIoTProtocolHTTPVersion "1.0.43"

#endif //AZUREIOTPROTOCOLHTTP_H
